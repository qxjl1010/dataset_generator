import jieba
import codecs 
import datetime
import random
import numpy

from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.svm import SVC
from sklearn.pipeline import Pipeline


class KGQA1():

    # 训练模型
    def __init__(self):
        self.disease_list = []
        self.Question_list = []
        self.L_Question_list = []
        self.Type_list = []
        self.L_Type_list = []
        with codecs.open('./kgqa/disease.txt',encoding='utf-8') as infile:
   
            i = 0
            for line in infile:
                if i == 0:
                    self.disease_list.append(line[1:-5])
                    i += 1
                    continue
                if line[:-5] not in self.disease_list:
                    self.disease_list.append(line[:-5])
        infile.close()

        with codecs.open('./kgqa/Q.txt', encoding='utf-8') as infile:
            i = 0
            for line in infile:
                if i == 0:
                    i += 1
                    continue
                elif i == 1:
                    line = line.replace('偏头痛','XXX')
                    self.Question_list.append(line[:-3])
                    i += 1
                    continue
                line = line.replace('偏头痛','XXX')
                if line[:-2] not in self.Question_list:
                    self.Question_list.append(line[:-2])
                else:
                    print(line)
        infile.close()

        with open('./kgqa/T.txt') as infile:
            for line in infile:
                self.Type_list.append(int(line[:-1]))
        infile.close()

        for i in range(1):
            for line,type in zip(self.Question_list,self.Type_list):
                seg = line.replace('XXX',self.disease_list[i])
                seg_list = jieba.lcut(seg, cut_all=False)
                q_addSpace = ''
                for w in seg_list:
                    q_addSpace = q_addSpace + w + ' '
                self.L_Question_list.append(q_addSpace[:-1])
                self.L_Type_list.append(type)

        li=list(range(len(self.L_Question_list)))
        random.shuffle(li)  

        shuffled_L_Question_list = [x for _,x in sorted(zip(li,self.L_Question_list))]
        shuffled_L_Type_list = [x for _,x in sorted(zip(li,self.L_Type_list))]

        model = Pipeline([('vect', TfidfVectorizer()), ('tfidf', TfidfTransformer()), ('clf', SVC(C=0.99, kernel = 'linear', probability=True))])
        model = model.fit(shuffled_L_Question_list, shuffled_L_Type_list)
        self.model = model

    def find_disease(self, q):
        for i in range(len(q)):
            for j in range(len(q) - i):
                if q[i:len(q)-j] in self.disease_list:
                    thisDisease = q[i:len(q)-j]
                    q = q.replace(q[i:len(q)-j], 'XXX')
                    return q, thisDisease
    
        return q, 'null'

    # 回答问题
    def answering(self, q):
    
        q,thisDisease = self.find_disease(q)
                    
        seg_list = jieba.lcut(q, cut_all=False)
        q_addSpace = ''
        for w in seg_list:
            q_addSpace = q_addSpace + w + ' '
        print(q_addSpace[:-1])
        predicted = self.model.predict([q_addSpace[:-1]])
        pred_prob = self.model.predict_proba([q_addSpace[:-1]])
        if predicted[0] == 1:
            thisIntent = '治疗方法'
        elif predicted[0] == 2:
            thisIntent = '推荐检查'
        elif predicted[0] == 3:
            thisIntent = '推荐药品'
        elif predicted[0] == 4:
            thisIntent = '症状'
        elif predicted[0] == 5:
            thisIntent = '病因'
        elif predicted[0] == 6:
            thisIntent = '并发'
        elif predicted[0] == 7:
            thisIntent = '倾向性'
        elif predicted[0] == 8:
            thisIntent = '部位'

        return thisDisease, thisIntent
'''
text_clf = train_model()
while True:
    q = input('请输入您的问题: ')
    d,i = answering(text_clf, q)
    print(d)
    print(i)
'''